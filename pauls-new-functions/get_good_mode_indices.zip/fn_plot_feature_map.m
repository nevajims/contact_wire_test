function fn_plot_feature_map(rail_tester, distance, options);
default_options.norm_to_what = 1;%1 - normalised to maximum in map, 2 = normalised to maximum in data
default_options.db_scale = 1;
default_options.db_range = 40;
default_options.dist_tol = 1; %distance tolerance band around nominal distance to consider set to zero for exact interpolation
default_options.grid_size = 100;
default_options.modes = [3, 5, 7, 8, 10];

options = set_default_fields(options, default_options);

[tx_mode, rx_mode] = meshgrid(options.modes, options.modes);
data = zeros(size(tx_mode));

if distance > 0
    dir = 1;
else
    dir = -1;
end;

for ii = 1:length(tx_mode(:))
    jj = find((rail_tester.proc_data.tx_mode == tx_mode(ii)) ...
        & (rail_tester.proc_data.rx_mode == rx_mode(ii)) ...
        & (rail_tester.proc_data.tx_dir == dir) ...
        & (rail_tester.proc_data.rx_dir == dir));
    if ~isempty(jj)
        if options.dist_tol <= 0
            data(ii) = interp1(rail_tester.proc_data.dist, abs(rail_tester.proc_data.dist_data(:, jj)), abs(distance), 'linear');
        else
            i1 = min(find(rail_tester.proc_data.dist > abs(distance) - options.dist_tol / 2));
            i2 = max(find(rail_tester.proc_data.dist < abs(distance) + options.dist_tol / 2));
            data(ii) = max(abs(rail_tester.proc_data.dist_data(i1:i2, jj)));
        end;
    end;
end;

if options.norm_to_what == 1
    data = data / max(max(abs(data)));
else
    data = data / max(max(abs(rail_tester.proc_data.dist_data)));
end;

if options.db_scale
    data = 20 * log10(data) + options.db_range;
    data(find(data<0)) = 0;
    data(find(isnan(data) |isinf(data))) = 0;
end;

[xi,yi] = meshgrid(linspace(1,length(options.modes),options.grid_size),linspace(1,length(options.modes),options.grid_size));
interp_data = interp2([1:length(options.modes)],[1:length(options.modes)],data,xi,yi);

surf(xi, yi, interp_data);
view(2);
axis equal;
shading flat;
axis off;
if options.db_scale
    caxis([0, options.db_range]);
end;
return;